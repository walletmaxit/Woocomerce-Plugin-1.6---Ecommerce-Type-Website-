<?php
/*
 * Plugin Name: walletmaxpay Gateway
 * Plugin URI: https://developer.walletmaxpay.com/
 * Description: This plugin allows your customers to pay with Bkash, Nagad, Rocket, Upay, Perfect Money, Bkash Merchent Live Payment via walletmaxpay
 * Author: walletmaxpay
 * Author URI: https://walletmaxpay.com/
 * Version: 1.2
 */
 
 /*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
 
 if(isset($_GET['success'])){
      $DB_HOST = constant("DB_HOST");
      $DB_USER = constant("DB_USER");
      $DB_PASS = constant("DB_PASSWORD");
      $DB_NAME = constant("DB_NAME");
      
      $sqlconn=mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
      
      $success = $_GET['success'];
      
      global $wpdb;
      global $table_prefix;
      
      $table_pre = $table_prefix.'posts';
      
        $transactionId = $_GET['transactionId'];
        $paymentAmount = $_GET['paymentAmount'];
        $paymentFee = $_GET['paymentFee'];

        $transaction_id_walletmaxpay = $transactionId;

        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://pay.walletmaxpay.com/verify.php',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('transaction_id' => $transaction_id_walletmaxpay),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        
        if($response == 1){

              $sql = "UPDATE $table_pre SET `post_status`='wc-processing' WHERE ID='$success'";
              if(mysqli_query($sqlconn,$sql)){
?>
                  <script>
                      location.href="../my-account/orders/";
                  </script>
<?php
              }
          }else{
            echo "Failed. Id Not Match";
          }
 }

 if(isset($_GET['bank'])){
      $DB_HOST = constant("DB_HOST");
      $DB_USER = constant("DB_USER");
      $DB_PASS = constant("DB_PASSWORD");
      $DB_NAME = constant("DB_NAME");
      
      $sqlconn=mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
      
      $bank = $_GET['bank'];
      
      global $wpdb;
      global $table_prefix;
      
      $table_pre = $table_prefix.'posts';

        $transactionId = $_GET['transactionId'];
        $paymentAmount = $_GET['paymentAmount'];
        $paymentFee = $_GET['paymentFee'];

        $transaction_id_walletmaxpay = $transactionId;

        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://pay.walletmaxpay.com/verify.php',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('transaction_id' => $transaction_id_walletmaxpay),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        

        if($response == 1){

      $sql = "UPDATE $table_pre SET `post_status`='wc-on-hold' WHERE ID='$bank'";
      if(mysqli_query($sqlconn,$sql)){
?>
          <script>
              location.href="../my-account/orders/";
          </script>
<?php
      }
  }else{
            echo "Failed. Id Not Match";
          }
 }
 
add_filter( 'woocommerce_payment_gateways', 'walletmaxpay_add_gateway_class' );
function walletmaxpay_add_gateway_class( $gateways ) {
    $gateways[] = 'WC_walletmaxpay_Gateway'; // your class name is here
    return $gateways;
}

/*
 * The class itself, please note that it is inside plugins_loaded action hook
 */
add_action( 'plugins_loaded', 'walletmaxpay_init_gateway_class' );
function walletmaxpay_init_gateway_class() {

    class WC_walletmaxpay_Gateway extends WC_Payment_Gateway {

        /**
         * Class constructor, more about it in Step 3
         */
        public function __construct() {

            $this->id = 'walletmaxpay'; // payment gateway plugin ID
            $this->icon = ''; // URL of the icon that will be displayed on checkout page near your gateway name
            $this->has_fields = false; // in case you need a custom credit card form
            $this->method_title = 'walletmaxpay Gateway';
            $this->method_description = 'pay with Bkash, Nagad, Rocket, Upay, Perfect Money, Bkash Merchent Live Payment via walletmaxpay'; // will be displayed on the options page
        
            // gateways can support subscriptions, refunds, saved payment methods,
            // but in this tutorial we begin with simple payments
            $this->supports = array(
                'products'
            );
        
            // Method with all the options fields
            $this->init_form_fields();
        
            // Load the settings.
            $this->init_settings();
            $this->title = $this->get_option( 'title' );
            $this->description = $this->get_option( 'description' );
            $this->enabled = $this->get_option( 'enabled' );

            // This action hook saves the settings
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            add_action('woocommerce_api_wc_gateway_' . $this->id, array($this, 'handle_webhook'));
        
        }

        /**
         * Plugin options, we deal with it in Step 3 too
         */
        public function init_form_fields(){


            $this->form_fields = array(
                'enabled' => array(
                    'title'       => 'Enable/Disable',
                    'label'       => 'Enable walletmaxpay Gateway',
                    'type'        => 'checkbox',
                    'description' => '',
                    'default'     => 'no'
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default'     => 'walletmaxpay Payment gateway',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default'     => 'Pay with Bkash, Nagad, Rocket via walletmaxpay',
                ),
                'apikeys' => array(
                    'title'       => 'Enter Api Key',
                    'type'        => 'text',
                    'description' => '',
                    'default'     => '12345',
                    'desc_tip'    => true,
                ),
                'clientkey' => array(
                    'title'       => 'Enter Client Key',
                    'type'        => 'text',
                    'description' => '',
                    'default'     => '12345',
                    'desc_tip'    => true,
                ),
                'secretkey' => array(
                    'title'       => 'Enter Secret Key',
                    'type'        => 'text',
                    'description' => '',
                    'default'     => '12345',
                    'desc_tip'    => true,
                ),
                'hostname' => array(
                    'title'       => 'Enter Host Name',
                    'type'        => 'text',
                    'description' => '',
                    'default'     => 'https://example.com',
                    'desc_tip'    => true,
                ),
                'currency_rate' => array(
                    'title'       => 'Enter USD Rate',
                    'type'        => 'number',
                    'description' => '',
                    'default'     => '85',
                    'desc_tip'    => true,
                )
                
                
            );
    
    
        }

        /*
         * We're processing the payments here, everything about it is in Step 5
         */
        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );
            
            
            global $woocommerce;
            $orders = new WC_Order($order_id);
                
            
            
            
            $current_user = wp_get_current_user();
            


            foreach ( $order->get_items() as $item_id => $item ) {
               $product_id = $item->get_product_id();
               $variation_id = $item->get_variation_id();
               $product = $item->get_product(); // see link above to get $product info
               $product_name = $item->get_name();
               $quantity = $item->get_quantity();
               $subtotal = $item->get_subtotal();
               $total = $item->get_total();
               $tax = $item->get_subtotal_tax();
               $tax_class = $item->get_tax_class();
               $tax_status = $item->get_tax_status();
               $allmeta = $item->get_meta_data();
               $somemeta = $item->get_meta( '_whatever', true );
               $item_type = $item->get_type(); // e.g. "line_item", "fee"
            }
            
            
            
            
            
            $subtotal                = WC()->cart->subtotal;
            $shipping_total          = WC()->cart->get_shipping_total();
            $fees                    = WC()->cart->get_fee_total();
            $discount_excl_tax_total = WC()->cart->get_cart_discount_total();
            $discount_tax_total      = WC()->cart->get_cart_discount_tax_total();
                        
            $discount_total          = $discount_excl_tax_total + $discount_tax_total;
            $total = $subtotal + $shipping_total + $fees - $discount_total;
            
            
            if($order->get_currency() == 'USD'){
                $total = $total*$this->get_option('currency_rate');
            }
            
           // $woocommerce->cart->empty_cart();

            if ($order->get_status() != 'completed') {
                $order->update_status('pending', __('Customer is being redirected to walletmaxpay Gateway', 'walletmaxpay'));
            }
    
            
            return array(
                'result'    => 'success',
                'redirect'  => 'https://pay.walletmaxpay.com/woocommerce_checkout.php?api='.$this->get_option('apikeys').'&client='.$this->get_option('clientkey').'&secret='.$this->get_option('secretkey').'&amount='.$total.'&position='.$this->get_option('hostname').'&success_url='.wc_get_page_permalink( 'checkout' ).'?success='.$order_id.'&cancel_url='.wc_get_page_permalink( 'checkout' ).'?edokan=true&cus_name='.$order_id.'&cus_email='.$current_user->user_email.'&done'
            );
        }
        


        
        
    }
}
 
